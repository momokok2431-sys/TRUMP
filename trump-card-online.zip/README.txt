# トランプカード選択表
GitHub Pagesに `index.html` を公開してください。
Firebase Realtime Database のルールには `database.rules.json` の内容を設定してください。

Firebase設定は index.html に入っています。
参加者は匿名認証で利用するため、Google等のアカウントは不要です。
